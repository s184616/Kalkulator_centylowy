# create global variables

background_color = "#ffcc99"
selected_pesel = ""
selected_patient_gender = "boy"
# imie_nazwisko_pacjenta = "test"
